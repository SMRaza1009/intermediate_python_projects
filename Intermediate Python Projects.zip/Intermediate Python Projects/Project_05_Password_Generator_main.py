import random

print('Welcome to password generator')

chars = 'abcdefghjklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*().,?0123456789'

num = int(input('enter the amount passwords to generate: '))

len = input('Input your password length: ')

len = int(len)

print('\nhere are your passwords:')

for pwd in range(num):
    passwords = ''
    for c in range(len):
        passwords += random.choice(chars)
    print(passwords)    