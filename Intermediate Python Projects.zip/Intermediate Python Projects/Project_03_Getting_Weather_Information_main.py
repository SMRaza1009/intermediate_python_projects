import requests
from pprint import pprint


API_Key = '33dfc5af4269eb0d9b0d5e1edd52b3c4'

city_name = input('enter city name: ')

base_url = "https://api.openweathermap.org/data/2.5/weather?appid="+API_Key+"&q="+city_name


weather_data = requests.get(base_url).json()


pprint(weather_data)