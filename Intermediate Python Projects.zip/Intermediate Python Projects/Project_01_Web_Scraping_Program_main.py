import requests
from bs4 import BeautifulSoup as bs

user_input = input("Input the Github username: ")
url = "https://github.com/"+user_input
send_req = requests.get(url)

soup = bs(send_req.content, 'html.parser') # Content = getting all the html content and html.parser will get all the html content and

github_profile_image = soup.find('img', {'alt': 'Avatar'})['src']
print(github_profile_image)
repo_list = soup.find_all('span', {'class': 'repo'})
print(repo_list)