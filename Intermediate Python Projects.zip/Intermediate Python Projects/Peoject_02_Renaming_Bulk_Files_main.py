import os


def main():
    i = 0
    path = "E:/Research/IMG Processing/Digital Image Processing Python/flowers/astilbe/"
    for filename in os.listdir(path):
        my_destination = "img"+str(i)+".jpg"
        my_source = path + filename
        my_destination = path + my_destination
        os.rename(my_source, my_destination)
        i += 1

if __name__ == "__main__":
    main()        
             